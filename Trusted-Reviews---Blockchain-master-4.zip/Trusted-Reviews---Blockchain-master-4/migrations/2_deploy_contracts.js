var addproperty = artifacts.require("addproperty");
module.exports = function(deployer){
    deployer.deploy(addproperty);
}
